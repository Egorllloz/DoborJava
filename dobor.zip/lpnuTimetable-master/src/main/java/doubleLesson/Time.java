package doubleLesson;

public class Time {

    public static final String FIRST =  "08:30 - 10:05";
    public static final String SECOND = "10:20 - 11:55";
    public static final String THIRD =  "12:10 - 13:45";
    public static final String FOURTH = "14:15 - 15:50";
    public static final String FIFTH =  "16:00 - 17:35";
    public static final String SIXTH =  "17:40 - 19:15";
    public static final String SEVENTH =  "19:20 - 20:55";
    public static final String EIGHTH =  "21:00 - 22:35";
}
